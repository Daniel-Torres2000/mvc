<?php
/* Smarty version 4.0.4, created on 2022-03-30 15:45:13
  from 'C:\xampp\htdocs\Proyecto\View\Encabezados\Encabezado.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_62445ee9a82f27_71966619',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a703b99e58963c58c0297b335f6264b43346df2a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto\\View\\Encabezados\\Encabezado.tpl',
      1 => 1647446976,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62445ee9a82f27_71966619 (Smarty_Internal_Template $_smarty_tpl) {
?><head>
    <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="?Controller=Direcciones&Method=IrSass">Sass</a></li>
        <li><a href="?Controller=Direcciones&Method=IrComponente">Components</a></li>
        <li><a href="collapsible.html">JavaScript</a></li>
      </ul>
    </div>
  </nav>
</head><?php }
}
