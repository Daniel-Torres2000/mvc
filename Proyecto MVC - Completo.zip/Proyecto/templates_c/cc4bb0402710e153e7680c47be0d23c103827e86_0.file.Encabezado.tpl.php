<?php
/* Smarty version 4.0.4, created on 2022-03-16 17:09:40
  from 'C:\xampp\htdocs\Proyecto3\View\Encabezados\Encabezado.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_62320bc41a2a81_38668405',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc4bb0402710e153e7680c47be0d23c103827e86' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto3\\View\\Encabezados\\Encabezado.tpl',
      1 => 1647446975,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62320bc41a2a81_38668405 (Smarty_Internal_Template $_smarty_tpl) {
?><head>
    <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="?Controller=Direcciones&Method=IrSass">Sass</a></li>
        <li><a href="?Controller=Direcciones&Method=IrComponente">Components</a></li>
        <li><a href="collapsible.html">JavaScript</a></li>
      </ul>
    </div>
  </nav>
</head><?php }
}
