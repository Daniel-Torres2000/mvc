<?php
/* Smarty version 4.0.4, created on 2022-03-30 15:45:13
  from 'C:\xampp\htdocs\Proyecto\View\Cabecera\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_62445ee9b06d31_68161501',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bb3a60a3dc7cfbc4bbb0d90bd629519a447cfee9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto\\View\\Cabecera\\Footer.tpl',
      1 => 1647444028,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62445ee9b06d31_68161501 (Smarty_Internal_Template $_smarty_tpl) {
?>      <!--JavaScript at end of body for optimized loading-->
      <?php echo '<script'; ?>
 type="text/javascript" src="Framework/Materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
  </html>


<?php }
}
