<?php
/* Smarty version 4.0.4, created on 2022-04-01 17:41:57
  from 'C:\xampp\htdocs\ProyectoA\View\piepagina.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_62471d45195343_56394530',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '218106102d369905737ebada1e711f2c32fad9ff' => 
    array (
      0 => 'C:\\xampp\\htdocs\\ProyectoA\\View\\piepagina.tpl',
      1 => 1648827689,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62471d45195343_56394530 (Smarty_Internal_Template $_smarty_tpl) {
?><footer>
    2022 copyright.....bla bla bla
</footer><?php }
}
