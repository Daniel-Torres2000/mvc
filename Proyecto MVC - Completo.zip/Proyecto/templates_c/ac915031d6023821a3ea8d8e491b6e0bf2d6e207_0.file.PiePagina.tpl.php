<?php
/* Smarty version 4.0.4, created on 2022-03-16 16:31:00
  from 'C:\xampp\htdocs\Proyecto3\View\Encabezados\PiePagina.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_623202b4b3d271_01323793',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac915031d6023821a3ea8d8e491b6e0bf2d6e207' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto3\\View\\Encabezados\\PiePagina.tpl',
      1 => 1647444027,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_623202b4b3d271_01323793 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="page-footer">
    <div class="footer-copyright">
        <div class="container">
            © 2022 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
        </div>
    </div>
</footer><?php }
}
