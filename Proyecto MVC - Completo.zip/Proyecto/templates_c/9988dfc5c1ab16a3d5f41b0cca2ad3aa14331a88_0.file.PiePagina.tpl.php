<?php
/* Smarty version 4.0.4, created on 2022-03-30 15:45:13
  from 'C:\xampp\htdocs\Proyecto\View\Encabezados\PiePagina.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_62445ee9aca837_49705959',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9988dfc5c1ab16a3d5f41b0cca2ad3aa14331a88' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto\\View\\Encabezados\\PiePagina.tpl',
      1 => 1647444028,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62445ee9aca837_49705959 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="page-footer">
    <div class="footer-copyright">
        <div class="container">
            © 2022 Copyright Text
            <a class="grey-text text-lighten-4 right" href="#!">More Links</a>
        </div>
    </div>
</footer><?php }
}
