<?php
/* Smarty version 4.0.4, created on 2022-03-16 16:20:31
  from 'C:\xampp\htdocs\Proyecto3\View\Cabecera\Footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.0.4',
  'unifunc' => 'content_6232003f3524e9_83088900',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '18d69b5da3872cf4047c142e8b6983e3599883ce' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Proyecto3\\View\\Cabecera\\Footer.tpl',
      1 => 1647444027,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6232003f3524e9_83088900 (Smarty_Internal_Template $_smarty_tpl) {
?>      <!--JavaScript at end of body for optimized loading-->
      <?php echo '<script'; ?>
 type="text/javascript" src="Framework/Materialize/js/materialize.min.js"><?php echo '</script'; ?>
>
    </body>
  </html>


<?php }
}
